
cd /home/cse/btech/cs1140245/BTP/rewrite
unbuffer python main.py > typed_distmult.txt
